#include <windows.h>
#include <stdio.h>
#include <string.h>  // For strncpy

// Function to initialize IPC (open shared memory), accepts memory name, memory size, handle, and buffer pointer
int initIPC(const char* sharedMemoryName, size_t memSize, HANDLE* hMapFile, char** pBuf)
{
    // Open an existing file mapping object (shared memory)
    *hMapFile = OpenFileMapping(
        FILE_MAP_ALL_ACCESS,   // Read/write access
        FALSE,                 // Do not inherit the name
        sharedMemoryName);     // Name of the shared memory object

    if (*hMapFile == NULL)
    {
        return 1;  // Return error code if file mapping failed
    }

    // Map a view of the file into the address space of the calling process
    *pBuf = (char*) MapViewOfFile(
        *hMapFile,             // Handle to the map object
        FILE_MAP_ALL_ACCESS,   // Read/write permission
        0,
        0,
        memSize);              // Size of the shared memory

    if (*pBuf == NULL)
    {
        CloseHandle(*hMapFile);
        return 2;  // Return error code if mapping view failed
    }

    return 0;  // Success
}

// Function to read data from shared memory and return as a string
const char* readIPC(char* pBuf, size_t bufSize)
{
    static char lastMessage[1024] = { 0 };  // Buffer to store the last read message

    // Check if new data is available
    if (strncmp(lastMessage, pBuf, bufSize) != 0)
    {
        // If the message is different from the last one, store the new message
        strncpy(lastMessage, pBuf, sizeof(lastMessage) - 1);  // Update the last message with bounds checking
        lastMessage[sizeof(lastMessage) - 1] = '\0';          // Ensure null termination
        return lastMessage;                                   // Return the new message as a string
    }

    return NULL;  // No new data
}

// Function to close IPC (cleanup), accepts shared memory handle and buffer pointer
void closeIPC(HANDLE hMapFile, char* pBuf)
{
    if (pBuf != NULL)
    {
        UnmapViewOfFile(pBuf);  // Unmap the memory
    }

    if (hMapFile != NULL)
    {
        CloseHandle(hMapFile);  // Close the file mapping
    }
}

// Function to parse the timestamp from the message string (format "Message X - Time: HH:MM:SS.mmm")
void parseMessageTime(const char* message, SYSTEMTIME* msgTime)
{
    int hour, minute, second, millisecond;
    
    // Parse the timestamp from the message (assuming it's in the format provided earlier)
    sscanf(message, "Message %*d - Time: %02d:%02d:%02d.%03d", &hour, &minute, &second, &millisecond);

    // Fill in the SYSTEMTIME structure
    msgTime->wHour = hour;
    msgTime->wMinute = minute;
    msgTime->wSecond = second;
    msgTime->wMilliseconds = millisecond;
}

// Function to calculate the time difference in milliseconds between two SYSTEMTIME values
int calculateTimeDifference(SYSTEMTIME* time1, SYSTEMTIME* time2)
{
    FILETIME ft1, ft2;
    ULARGE_INTEGER uli1, uli2;

    // Convert SYSTEMTIME to FILETIME (64-bit structure for comparison)
    SystemTimeToFileTime(time1, &ft1);
    SystemTimeToFileTime(time2, &ft2);

    // Convert FILETIME to ULARGE_INTEGER for easier time difference calculation
    uli1.LowPart = ft1.dwLowDateTime;
    uli1.HighPart = ft1.dwHighDateTime;

    uli2.LowPart = ft2.dwLowDateTime;
    uli2.HighPart = ft2.dwHighDateTime;

    // Calculate the time difference in 100-nanosecond intervals and convert to milliseconds
    return (int)((uli2.QuadPart - uli1.QuadPart) / 10000);
}

int main()
{
    const char* sharedMemoryName = "Local\\MySharedMemory";  // Example shared memory name
    size_t memSize = 1024;                                   // Example shared memory size
    HANDLE hMapFile = NULL;                                  // Local handle to shared memory
    char* pBuf = NULL;                                       // Local pointer to shared memory buffer

    // Step 1: Initialize IPC with a memory name and size
    int initStatus = initIPC(sharedMemoryName, memSize, &hMapFile, &pBuf);
    if (initStatus != 0)
    {
        // Handle error (no printf here, you can return error codes or log if necessary)
        return initStatus;  // Exit if initialization fails
    }

    // Step 2: Continuously read data from IPC in a loop
    while (1) 
    {
        const char* data = readIPC(pBuf, memSize);  // Read data from IPC

        if (data != NULL)
        {
            // Parse the message time from the received data
            SYSTEMTIME messageTime;
            parseMessageTime(data, &messageTime);

            // Get the current system time in milliseconds
            SYSTEMTIME currentTime;
            GetSystemTime(&currentTime);

            // Calculate the time difference between the message time and the received time
            int timeDiffMs = calculateTimeDifference(&messageTime, &currentTime);

            // Print the new data and the time of reception
            printf("Pipe data: %s", data);
            printf("      Mrcvd at %02d:%02d:%02d.%03d\n",
                   currentTime.wHour, 
                   currentTime.wMinute, 
                   currentTime.wSecond, 
                   currentTime.wMilliseconds);
                  

            // Print the time difference between message creation and reception
            //printf("Time difference : %d milliseconds\n", timeDiffMs);
        }

        Sleep(0);  // Sleep for 1 millisecond to avoid high CPU usage
    }

    // Step 3: Cleanup (this will never be reached in the current infinite loop)
    closeIPC(hMapFile, pBuf);

    return 0;
}
