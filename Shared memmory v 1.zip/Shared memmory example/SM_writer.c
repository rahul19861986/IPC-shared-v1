#include <windows.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

// Function to initialize IPC (create shared memory), accepts memory name and memory size as parameters
// Returns 0 on success, non-zero on failure
int initializeIPC(const char* sharedMemoryName, size_t sharedMemorySize, HANDLE* hMapFile, char** pBuf)
{
    // Create a file mapping (shared memory)
    *hMapFile = CreateFileMapping(
        INVALID_HANDLE_VALUE,    // Use paging file
        NULL,                    // Default security attributes
        PAGE_READWRITE,          // Read/write access
        0,                       // Maximum object size (high-order DWORD)
        sharedMemorySize,        // Maximum object size (low-order DWORD)
        sharedMemoryName);       // Name of the shared memory object

    if (*hMapFile == NULL)
    {
        return 1;  // Error creating file mapping
    }

    // Map a view of the file into the address space of the calling process
    *pBuf = (char*) MapViewOfFile(
        *hMapFile,               // Handle to the map object
        FILE_MAP_ALL_ACCESS,     // Read/write permission
        0,
        0,
        sharedMemorySize);

    if (*pBuf == NULL)
    {
        CloseHandle(*hMapFile);
        return 2;  // Error mapping view of file
    }

    return 0;  // Success
}

// Function to write data to shared memory
void writeIPC(char* pBuf, const char* message)
{
    // Write the formatted message to shared memory
    memcpy(pBuf, message, strlen(message) + 1);  // +1 for null-termination
}

// Function to close IPC (cleanup)
void closeIPC(HANDLE hMapFile, char* pBuf)
{
    if (pBuf != NULL)
    {
        UnmapViewOfFile(pBuf);  // Unmap the memory
    }

    if (hMapFile != NULL)
    {
        CloseHandle(hMapFile);  // Close the file mapping
    }
}

int main()
{
    const char* sharedMemoryName = "Local\\MySharedMemory";  // Example shared memory name
    size_t sharedMemorySize = 1024;                          // Example shared memory size
    HANDLE hMapFile = NULL;                                  // Handle to shared memory
    char* pBuf = NULL;                                       // Pointer to shared memory buffer
    int counter = 0;

    // Step 1: Initialize IPC with memory name and size
    int initResult = initializeIPC(sharedMemoryName, sharedMemorySize, &hMapFile, &pBuf);
    if (initResult != 0)
    {
        // Handle error - could return or log based on the initResult value
        return initResult;  // Exit if initialization fails
    }

    // Step 2: Continuously write data to IPC
    while (1) 
    {
        SYSTEMTIME st;
        char message[sharedMemorySize];

        // Get current system time
        GetSystemTime(&st);

        // Format the message with a millisecond timestamp
        sprintf(message, "Message %d - Time: %02d:%02d:%02d.%03d",
                counter,
                st.wHour,
                st.wMinute,
                st.wSecond,
                st.wMilliseconds);

        // Write the message to shared memory
        writeIPC(pBuf, message);

        // Simulate data writing by printing to the console in the main function
        printf("Data written to shared memory: %s\n", message);

        counter++;  // Increment message counter

        // Sleep for 1 millisecond before writing the next message
        Sleep(1);
    }

    // Step 3: Close IPC (cleanup) - never reached due to infinite loop
    closeIPC(hMapFile, pBuf);

    return 0;
}
